const categoryData = {
  dairy: { name: "Dairy", description: "Illustrative planning context for livestock and dairy-value enterprises—not official government cost data.", costs: ["Livestock & equipment", "Feed", "Labour", "Utilities", "Transport"], revenue: ["Milk", "Curd", "Paneer", "Dairy products"] },
  textile: { name: "Textile", description: "Illustrative planning context for small production and tailoring enterprises—not official government cost data.", costs: ["Sewing equipment", "Raw materials", "Labour", "Utilities", "Inventory"], revenue: ["Finished garments", "Tailoring", "Fabric products"] },
  agriculture: { name: "Agriculture", description: "Illustrative planning context for cultivation and farm-linked enterprises—not official government cost data.", costs: ["Equipment", "Seeds & inputs", "Irrigation", "Labour", "Transport"], revenue: ["Crop sales", "Value-added products", "Farm produce"] }
};
const schemes = {
  micro: { id: "micro", name: "Micro Finance Scheme", maxProject: 140000, maxLoan: 125000, rate: .065, years: 3, moratorium: 3 },
  term: { id: "term", name: "Term Loan Scheme", maxProject: 5000000, maxLoan: 4500000, rate: .08, years: 7, moratorium: 6 }
};
let selectedCategory = "dairy";
let result = null;
let scheduleExpanded = false;
const $ = (id) => document.getElementById(id);
const money = (number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(number || 0));
const numberFromInput = (value) => Number(String(value).replace(/[^0-9.]/g, ""));
const round = (value) => Math.round((value + Number.EPSILON) * 100) / 100;

function localSchedule(principal, annualRate, years, moratorium) {
  const rate = annualRate / 12;
  let balance = principal;
  for (let month = 0; month < moratorium; month += 1) balance = round(balance + balance * rate);
  const months = years * 12;
  const factor = Math.pow(1 + rate, months);
  const emi = round(balance * rate * factor / (factor - 1));
  const rows = [];
  let total = 0;
  for (let q = 1; q <= months / 3; q += 1) {
    const opening = balance; let payment = 0; let interestTotal = 0; let principalTotal = 0;
    for (let m = 0; m < 3; m += 1) {
      const interest = round(balance * rate);
      const paid = Math.min(emi, round(balance + interest));
      const principalPaid = round(paid - interest);
      balance = round(balance - principalPaid);
      payment = round(payment + paid); interestTotal = round(interestTotal + interest); principalTotal = round(principalTotal + principalPaid);
    }
    rows.push({ quarter: q, period: `Quarter ${q}`, opening_balance: opening, payment, principal_paid: principalTotal, interest_paid: interestTotal, closing_balance: Math.max(0, balance) });
    total = round(total + payment);
  }
  if (Math.abs(balance) > .1) { const last = rows.at(-1); last.payment = round(last.payment + balance); last.principal_paid = round(last.principal_paid + balance); last.closing_balance = 0; total = round(total + balance); }
  return { rows, total, interest: round(total - principal), quarterly: rows[0].payment };
}

function localCalculate({ location, business_category, margin_capital }) {
  const margin = Number(margin_capital), project = round(margin * 10);
  if (!(margin > 0)) throw new Error("Available margin capital must be greater than ₹0.");
  const scheme = project <= schemes.micro.maxProject ? schemes.micro : project <= schemes.term.maxProject ? schemes.term : null;
  if (!scheme) return { location, business_category, margin_capital: margin, project_cost: project, status: "outside_range", message: "The implied project cost is above the stated scheme range of ₹50,00,000.", repayment_schedule: [] };
  const theoretical = round(project * .9), loan = Math.min(theoretical, scheme.maxLoan), schedule = localSchedule(loan, scheme.rate, scheme.years, scheme.moratorium);
  return { location, business_category, margin_capital: margin, project_cost: project, loan_amount: loan, required_own_contribution: round(project - loan), financing_gap: Math.max(0, round(project - loan - margin)), scheme: scheme.name, scheme_id: scheme.id, interest_rate: scheme.rate, tenure_years: scheme.years, moratorium_months: scheme.moratorium, repayment_start: `After ${scheme.moratorium} months`, quarterly_payment: schedule.quarterly, total_repayment: schedule.total, total_interest: schedule.interest, cap_applied: loan < theoretical, status: "eligible", message: `Project cost is routed to the ${scheme.name}.${loan < theoretical ? ` The scheme maximum loan cap of ${money(scheme.maxLoan)} applies.` : ""}`, repayment_schedule: schedule.rows };
}

function updateCategory(category) {
  selectedCategory = category;
  document.querySelectorAll(".category").forEach((button) => button.classList.toggle("active", button.dataset.category === category));
}

function showContext(category) {
  const data = categoryData[category];
  $("contextTitle").textContent = data.name;
  $("contextDescription").textContent = data.description;
  $("costChips").innerHTML = data.costs.map((item) => `<span class="chip">${item}</span>`).join("");
  $("revenueChips").innerHTML = data.revenue.map((item) => `<span class="chip">${item}</span>`).join("");
}

function drawChart(rows) {
  const svg = $("balanceChart");
  if (!rows?.length) { svg.innerHTML = ""; return; }
  const values = [rows[0].opening_balance, ...rows.map((row) => row.closing_balance)];
  const max = Math.max(...values), width = 800, height = 190, top = 10, base = 200;
  const points = values.map((value, index) => `${(index / (values.length - 1)) * width},${base - (value / max) * height}`).join(" ");
  const fill = `${points} ${width},${base} 0,${base}`;
  svg.innerHTML = `<defs><linearGradient id="chartGradient" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#77a97b" stop-opacity=".3"/><stop offset="1" stop-color="#77a97b" stop-opacity="0"/></linearGradient></defs><line class="chart-grid" x1="0" y1="${top + 15}" x2="800" y2="${top + 15}"/><line class="chart-grid" x1="0" y1="105" x2="800" y2="105"/><line class="chart-grid" x1="0" y1="200" x2="800" y2="200"/><polygon class="chart-fill" points="${fill}"/><polyline class="chart-line" points="${points}"/><text class="chart-label" x="0" y="218">Repayment begins after moratorium</text><text class="chart-label" x="730" y="218">End of tenure</text>`;
}

function renderSchedule() {
  if (!result?.repayment_schedule) return;
  const rows = scheduleExpanded ? result.repayment_schedule : result.repayment_schedule.slice(0, 8);
  $("scheduleBody").innerHTML = rows.map((row) => `<tr><td>${row.period}</td><td>${money(row.opening_balance)}</td><td>${money(row.payment)}</td><td>${money(row.principal_paid)}</td><td>${money(row.interest_paid)}</td><td>${money(row.closing_balance)}</td></tr>`).join("");
  $("toggleSchedule").textContent = scheduleExpanded ? "Show first 8" : "View all";
}

function renderResult(data) {
  result = data; scheduleExpanded = false;
  ["blueprint", "repayment", "advisor"].forEach((id) => $(id).classList.remove("hidden"));
  showContext(data.business_category);
  const alert = $("resultAlert");
  if (data.status !== "eligible") {
    alert.className = "result-alert show"; alert.textContent = data.message;
    $("marginValue").textContent = money(data.margin_capital); $("projectValue").textContent = money(data.project_cost); $("loanValue").textContent = "Not available"; $("schemeValue").textContent = "Outside stated range";
    $("loanNote").textContent = "Project needs institutional review"; $("schemeNote").textContent = "Above ₹50 lakh stated range";
    $("schemeTitle").textContent = "No stated scheme route"; $("interestValue").textContent = "—"; $("tenureValue").textContent = "—"; $("moratoriumValue").textContent = "—"; $("maxLoanValue").textContent = "—"; $("interpretation").textContent = "The available rules cannot route this project cost. This prototype does not assess other schemes.";
    $("repayment").classList.add("hidden"); return;
  }
  alert.className = data.cap_applied ? "result-alert show" : "result-alert"; alert.textContent = data.cap_applied ? data.message : "";
  $("blueprintHeading").textContent = `${categoryData[data.business_category].name} Enterprise Blueprint`;
  $("blueprintSub").textContent = `${data.location} · Prototype demonstration data`;
  $("marginValue").textContent = money(data.margin_capital); $("projectValue").textContent = money(data.project_cost); $("loanValue").textContent = money(data.loan_amount); $("schemeValue").textContent = data.scheme;
  $("loanNote").textContent = data.cap_applied ? "Maximum loan cap applied" : "90% of calculated project cost"; $("schemeNote").textContent = `${(data.interest_rate * 100).toFixed(1)}% p.a. · ${data.tenure_years} years`;
  $("schemeTitle").textContent = data.scheme; $("interestValue").textContent = `${(data.interest_rate * 100).toFixed(1)}%`; $("tenureValue").textContent = `${data.tenure_years} years`; $("moratoriumValue").textContent = `${data.moratorium_months} months`; $("moratoriumNote").textContent = "No repayments due"; $("maxLoanValue").textContent = money(schemes[data.scheme_id].maxLoan);
  const gapText = data.financing_gap > 0 ? ` The stated margin is ${money(data.financing_gap)} below the required own contribution after the loan cap.` : "";
  $("interpretation").textContent = `With ${money(data.margin_capital)} in available margin capital, the 10% contribution rule corresponds to a ${money(data.project_cost)} project size. Under the stated parameters, this is routed to the ${data.scheme} with an eligible loan of ${money(data.loan_amount)}.${gapText}`;
  $("quarterlyValue").textContent = money(data.quarterly_payment); $("totalRepaymentValue").textContent = money(data.total_repayment); $("totalInterestValue").textContent = money(data.total_interest); $("repaymentStartValue").textContent = data.repayment_start; $("scheduleLength").textContent = `${data.repayment_schedule.length} quarterly periods`;
  drawChart(data.repayment_schedule); renderSchedule();
  setTimeout(() => $("blueprint").scrollIntoView({ behavior: "smooth", block: "start" }), 80);
}

async function getCalculation(payload) {
  try {
    const response = await fetch("/api/financial/calculate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error("Financial API unavailable");
    return await response.json();
  } catch (_) {
    $("advisorStatus").textContent = "Calculator running in offline mode";
    return localCalculate(payload);
  }
}

async function submitAssessment(event) {
  event.preventDefault();
  const location = $("location").value, margin = numberFromInput($("margin").value), error = $("formError");
  if (!location) { error.textContent = "Select your Gujarat district or location."; return; }
  if (!margin || margin <= 0) { error.textContent = "Enter a valid margin capital greater than ₹0."; return; }
  if (margin > 10000000) { error.textContent = "For this prototype, enter margin capital below ₹1 crore."; return; }
  error.textContent = "";
  const button = event.submitter || document.querySelector(".calculate");
  button.disabled = true; button.innerHTML = "Building blueprint…";
  const data = await getCalculation({ location, business_category: selectedCategory, margin_capital: margin });
  button.disabled = false; button.innerHTML = "Calculate financial blueprint <span>→</span>"; renderResult(data);
}

function loadDemo() { $("location").value = "Vadodara, Gujarat"; $("margin").value = "1,00,000"; updateCategory("dairy"); $("assessmentForm").requestSubmit(); }

function addMessage(text, type) { const node = document.createElement("div"); node.className = `message ${type === "user" ? "user-message" : "advisor-message"}`; node.textContent = text; $("chatBody").append(node); $("chatBody").scrollTop = $("chatBody").scrollHeight; }
async function sendChat(message) {
  if (!result || !message.trim()) return;
  addMessage(message.trim(), "user"); $("chatMessage").value = "";
  const pending = document.createElement("div"); pending.className = "message advisor-message"; pending.textContent = "Thinking with your calculated blueprint…"; $("chatBody").append(pending);
  try {
    const response = await fetch("/api/ai/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message, financial_context: result }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "AI Advisor is currently unavailable.");
    pending.textContent = data.reply; $("advisorStatus").textContent = "Explaining your calculated blueprint";
  } catch (error) {
    pending.textContent = "AI Advisor is currently unavailable. Financial calculations remain available."; $("advisorStatus").textContent = "AI Advisor unavailable · calculator remains available";
  }
  $("chatBody").scrollTop = $("chatBody").scrollHeight;
}

document.querySelectorAll(".category").forEach((button) => button.addEventListener("click", () => updateCategory(button.dataset.category)));
$("assessmentForm").addEventListener("submit", submitAssessment);
[$("demoTop"), $("demoHero"), $("demoForm")].forEach((button) => button.addEventListener("click", loadDemo));
$("toggleSchedule").addEventListener("click", () => { scheduleExpanded = !scheduleExpanded; renderSchedule(); });
$("printBlueprint").addEventListener("click", () => window.print());
$("chatForm").addEventListener("submit", (event) => { event.preventDefault(); sendChat($("chatMessage").value); });
document.querySelectorAll(".suggestions button").forEach((button) => button.addEventListener("click", () => sendChat(button.textContent)));
$("margin").addEventListener("input", (event) => { const raw = numberFromInput(event.target.value); event.target.value = raw ? new Intl.NumberFormat("en-IN").format(raw) : ""; });
showContext(selectedCategory);
