from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from app.financial.engine import calculate, schemes_payload

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"
DATA = Path(__file__).resolve().parent / "data" / "business_categories.json"

app = FastAPI(title="Gram Udyog API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["*"], allow_headers=["*"])

class FinancialRequest(BaseModel):
    location: str = Field(min_length=2, max_length=120)
    business_category: Literal["dairy", "textile", "agriculture"]
    margin_capital: float = Field(gt=0, le=10000000)

    @field_validator("location")
    @classmethod
    def gujarat_context(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Location is required.")
        return value.strip()

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1200)
    financial_context: dict

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/schemes")
def schemes():
    return schemes_payload()

@app.get("/api/business-categories")
def categories():
    return json.loads(DATA.read_text(encoding="utf-8"))

@app.post("/api/financial/calculate")
def financial_calculate(request: FinancialRequest):
    try:
        payload = calculate(request.margin_capital).payload()
        payload.update({"location": request.location, "business_category": request.business_category})
        return payload
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

@app.post("/api/ai/chat")
def ai_chat(request: ChatRequest):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise HTTPException(status_code=503, detail="AI Advisor is currently unavailable. Financial calculations remain available.")
    try:
        from openai import OpenAI
        system = """You are the Gram Udyog financial advisory assistant. Explain only the structured financial results supplied by the application. Never invent scheme parameters, loan limits, interest rates, eligibility criteria, or financial calculations. If information is unavailable, say so. Clearly distinguish prototype assumptions from official problem-statement parameters. Be concise, helpful, and plain-language; Hindi/Hinglish is welcome if the user uses it."""
        client = OpenAI(api_key=key)
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            messages=[{"role": "system", "content": system}, {"role": "user", "content": f"Authoritative result JSON: {json.dumps(request.financial_context)}\n\nUser question: {request.message}"}],
            temperature=0.2,
        )
        return {"reply": response.choices[0].message.content}
    except Exception as error:
        raise HTTPException(status_code=503, detail="AI Advisor is currently unavailable. Financial calculations remain available.") from error

if FRONTEND.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND), name="assets")

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")
