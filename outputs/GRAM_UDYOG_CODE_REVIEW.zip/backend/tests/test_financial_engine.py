import unittest
from decimal import Decimal

from app.financial.engine import calculate


class FinancialEngineTests(unittest.TestCase):
    def test_term_loan_demo_scenario(self):
        result = calculate(100000)
        self.assertEqual(result.project_cost, Decimal("1000000.00"))
        self.assertEqual(result.loan_amount, Decimal("900000.00"))
        self.assertEqual(result.scheme, "Term Loan Scheme")
        self.assertEqual(result.moratorium_months, 6)
        self.assertEqual(len(result.repayment_schedule), 28)

    def test_micro_scheme(self):
        result = calculate(10000)
        self.assertEqual(result.scheme, "Micro Finance Scheme")
        self.assertEqual(result.loan_amount, Decimal("90000.00"))
        self.assertEqual(result.tenure_years, 3)

    def test_cap_is_enforced(self):
        # ₹14,000 implies ₹1,40,000: still Micro, but 90% is ₹1,26,000.
        result = calculate(14000)
        self.assertEqual(result.project_cost, Decimal("140000.00"))
        self.assertEqual(result.scheme, "Micro Finance Scheme")
        self.assertEqual(result.loan_amount, Decimal("125000.00"))
        self.assertTrue(result.cap_applied)

    def test_outside_range(self):
        result = calculate(600000)
        self.assertEqual(result.status, "outside_range")
        self.assertIsNone(result.loan_amount)

    def test_invalid_margin(self):
        with self.assertRaises(ValueError):
            calculate(0)


if __name__ == "__main__":
    unittest.main()
